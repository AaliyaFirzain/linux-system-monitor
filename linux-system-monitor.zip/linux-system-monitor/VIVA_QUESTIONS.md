# Operating Systems CCA Viva Preparation Guide

This document contains 25+ essential viva examination questions and answers tailored for undergraduate Operating Systems Continuous Comprehensive Assessment (CCA). Every answer is concise, technically precise, and directly connected to the architecture of the **Linux System Information Monitor**.

---

### Q1. What is Linux?
**Answer:** Linux is an open-source, monolithic, Unix-like operating system kernel created by Linus Torvalds in 1991. When combined with GNU system utilities, libraries, and user-space applications, it forms a complete Linux distribution (e.g., Ubuntu, Debian, Fedora, Arch) that manages system hardware, processes, memory, and devices.

---

### Q2. What is the `/proc` filesystem?
**Answer:** `/proc` is a special pseudo-filesystem (virtual filesystem) provided by the Linux kernel. It acts as an interface between user-space programs and kernel-space data structures, exposing live system statistics, hardware configurations, and process information formatted as readable ASCII text files.

---

### Q3. Why is `/proc` called a "virtual" or "pseudo" filesystem?
**Answer:** It is called virtual because it does not exist on any physical storage media like a hard disk or SSD. The files and directories inside `/proc` do not consume disk space; they are generated dynamically in RAM by the kernel at the exact moment a read operation (`open()`, `read()`) occurs.

---

### Q4. What is a kernel?
**Answer:** The kernel is the core component of an operating system that executes with the highest CPU privilege level (Kernel Mode / Ring 0). It is responsible for process management, CPU scheduling, virtual memory management, interrupt handling, device driver communication, and enforcing security boundaries.

---

### Q5. What is the difference between Kernel Space and User Space?
**Answer:**
- **Kernel Space**: A protected memory area where the core OS kernel and device drivers execute with unrestricted access to CPU instructions and physical hardware.
- **User Space**: The restricted memory area where normal user applications (such as our web browser and Python backend) execute in unprivileged mode (Ring 3), isolated from each other and unable to directly touch hardware.

---

### Q6. What is a system call (syscall)?
**Answer:** A system call is the programmatic interface via which an unprivileged user-space application requests services from the kernel (e.g., `fork()`, `execve()`, `read()`, `write()`, `kill()`). The CPU executes a software interrupt or a dedicated instruction (`syscall` / `sysenter`) to transition from User Mode to Kernel Mode.

---

### Q7. What is a Process?
**Answer:** A process is an instance of a computer program in execution. It represents the fundamental unit of resource allocation in an operating system and consists of program code (text section), current activity (program counter and CPU registers), stack (temporary data/local variables), data section (global variables), and heap (dynamically allocated memory).

---

### Q8. What is the Process Control Block (PCB)?
**Answer:** The PCB (implemented as `struct task_struct` in the Linux kernel) is the data structure maintained by the kernel for every active process. It stores the PID, process state, program counter, CPU registers, scheduling priority, memory management information, and list of open file descriptors.

---

### Q9. What is a PID (Process Identifier)?
**Answer:** A PID is a unique positive integer assigned by the kernel to identify an active process in the system. The kernel guarantees that no two active processes share the same PID simultaneously. When a process terminates, its PID may eventually be recycled.

---

### Q10. What is a PPID (Parent Process Identifier)?
**Answer:** A PPID is the PID of the process that created the child process using the `fork()` system call. In Unix-like systems, all processes form a hierarchical tree stemming from the initial process (`systemd` or `init`, PID 1).

---

### Q11. What is the difference between a Process and a Thread?
**Answer:**
- **Process**: An independent execution unit with its own private virtual address space, file descriptors, and system resources. Context switching between processes is relatively expensive.
- **Thread**: Often called a Lightweight Process (LWP), a thread is the smallest schedulable unit of CPU execution. Multiple threads within the same process share the same virtual address space, global variables, and open files, but maintain their own individual stacks and registers.

---

### Q12. What are the common Process States in Linux?
**Answer:**
- **R (Running / Runnable)**: The process is either currently executing on a CPU or waiting in the scheduler's run-queue.
- **S (Interruptible Sleep)**: The process is waiting for an event or resource (such as user input, disk I/O, or a timer) and can be awakened by signals.
- **D (Uninterruptible Sleep / Disk Sleep)**: The process is waiting for hardware I/O and cannot be interrupted, not even by `kill -9`.
- **Z (Zombie / Defunct)**: The process has finished execution via `exit()`, but its exit status has not yet been read by its parent via `wait()`. It consumes no CPU or RAM, only a slot in the process table.
- **T (Stopped / Traced)**: The process execution was halted by a job control signal (e.g., `SIGSTOP`, `Ctrl+Z`) or by a debugger using `ptrace`.

---

### Q13. What is a Zombie Process, and why does it exist?
**Answer:** A zombie process occurs when a child process terminates, but its parent process has not yet invoked the `wait()` or `waitpid()` system call to collect the child's termination status. The kernel retains the child's PID and exit status in the process table so the parent can inspect how the child terminated. Once the parent reads the exit status (or if the parent terminates and PID 1 adopts and reaps the child), the zombie is removed from the process table.

---

### Q14. What is an Orphan Process?
**Answer:** An orphan process is a running child process whose parent terminated prematurely. In Linux, orphan processes are automatically adopted by the system initialization daemon (`systemd` or `init`, PID 1), which periodically invokes `wait()` to reap them when they finish.

---

### Q15. What is CPU Utilization?
**Answer:** CPU utilization is the fraction or percentage of time during which the processor is actively executing instructions (in user mode, system mode, handling interrupts, etc.) compared to the total elapsed time, which includes idle time.

---

### Q16. How is CPU utilization calculated from `/proc/stat`?
**Answer:**
`/proc/stat` maintains cumulative time counters in units of jiffies:
1. $\text{Idle} = \text{idle} + \text{iowait}$
2. $\text{NonIdle} = \text{user} + \text{nice} + \text{system} + \text{irq} + \text{softirq} + \text{steal}$
3. $\text{Total} = \text{Idle} + \text{NonIdle}$
4. By taking two successive readings at time $T_1$ and $T_2$:
   $$\Delta\text{Total} = \text{Total}_2 - \text{Total}_1$$
   $$\Delta\text{Idle} = \text{Idle}_2 - \text{Idle}_1$$
   $$\text{CPU Utilization \%} = \left(\frac{\Delta\text{Total} - \Delta\text{Idle}}{\Delta\text{Total}}\right) \times 100$$

---

### Q17. Why can't CPU utilization be measured from a single snapshot of `/proc/stat`?
**Answer:** Because `/proc/stat` stores cumulative time counters starting from the moment the system booted. A single snapshot only reflects the total historical average since boot time, not the current instantaneous activity. Two successive readings separated by an interval are required to measure work done over that specific time delta.

---

### Q18. What is RAM and how does virtual memory work?
**Answer:** RAM (Random Access Memory) is physical volatile memory used by the CPU for fast data and instruction access. In modern operating systems, processes do not access physical RAM directly; they operate in **Virtual Memory**. The Memory Management Unit (MMU) uses page tables to translate process virtual addresses into physical RAM page frames, providing memory protection, process isolation, and the illusion of contiguous memory.

---

### Q19. How is memory utilization calculated from `/proc/meminfo`?
**Answer:**
In modern Linux kernels (version $\ge$ 3.14):
$$\text{Used RAM} = \text{MemTotal} - \text{MemAvailable}$$
$$\text{Memory Utilization \%} = \left(\frac{\text{Used RAM}}{\text{MemTotal}}\right) \times 100$$
`MemAvailable` is computed by the kernel to accurately estimate how much memory can be allocated to new applications without forcing the system into swap, accounting for file caches and slab objects that can be freed on demand.

---

### Q20. What is the difference between `MemFree` and `MemAvailable` in `/proc/meminfo`?
**Answer:**
- `MemFree` is the raw amount of physical RAM that is completely untouched and unallocated. Linux intentionally minimizes completely free RAM by using it for disk caching.
- `MemAvailable` is the true estimate of memory available for new applications. It includes `MemFree` PLUS reclaimable page caches and buffers that the kernel can discard immediately if memory is needed.

---

### Q21. What is Swap Memory?
**Answer:** Swap is a dedicated disk partition or file used as an extension of physical RAM. When physical RAM becomes scarce, the kernel's pager daemon moves inactive (cold) memory pages from RAM to swap space, freeing up RAM for active processes. If swapped pages are accessed again, a page fault occurs, and the kernel brings them back into physical RAM.

---

### Q22. What is System Uptime and where is it recorded?
**Answer:** System uptime is the continuous elapsed time in seconds since the Linux operating system finished booting. It is recorded as the first floating-point value in `/proc/uptime`. The second value represents the cumulative idle time across all CPU cores.

---

### Q23. What is System Load Average?
**Answer:** System load average, exposed in `/proc/loadavg`, represents the average number of processes that are either actively running, runnable (waiting in the CPU run-queue), or waiting for uninterruptible disk I/O over 1-minute, 5-minute, and 15-minute moving windows.

---

### Q24. How do you interpret load averages relative to CPU cores?
**Answer:**
- If load average equals the number of logical CPU cores, the CPU is at 100% capacity without backlog.
- If load average is less than the core count, the processor has idle capacity.
- If load average exceeds the core count, processes are queueing, indicating CPU contention or I/O bottlenecks.

---

### Q25. What is VmRSS in `/proc/[PID]/status`?
**Answer:** VmRSS stands for **Virtual Memory Resident Set Size**. It represents the exact portion of a process's virtual memory that is currently held in physical RAM (page frames), excluding swapped-out pages or unallocated virtual space. It is the most accurate indicator of a process's actual RAM footprint.

---

### Q26. Why is periodic refreshing (polling) essential for a system monitor?
**Answer:** System metrics such as CPU counters, RAM consumption, network I/O, and process execution states are highly dynamic and fluctuate continuously. Periodic polling (e.g., every 2 seconds) retrieves fresh kernel telemetry at regular intervals, allowing administrators to observe real-time spikes, detect memory leaks, and track transient processes without requiring manual page reloads.

---

### Q27. Why should normal system monitoring tools avoid requiring `root` (superuser) privileges?
**Answer:** Under the **Principle of Least Privilege**, software should only run with the minimum permissions required to perform its function. The `/proc` virtual files (`/proc/stat`, `/proc/meminfo`, `/proc/uptime`, `/proc/loadavg`, and public process status files) are world-readable (`chmod 444`) by design. Running monitoring tools without root prevents accidental system modification, privilege escalation vulnerabilities, and potential security exploits.
