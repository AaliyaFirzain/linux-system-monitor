# Linux System Information Monitor (OS CCA Project)

A professional, modular, full-stack Operating Systems continuous comprehensive assessment (CCA) application designed to dynamically extract, compute, and visualize real-time Linux kernel diagnostics, system metrics, hardware telemetry, and process states without relying on any mock or hardcoded statistics.

---

## Table of Contents
1. [Project Overview](#project-overview)
2. [Problem Statement](#problem-statement)
3. [Objectives](#objectives)
4. [Strict Engineering Standard: No Hardcoded Data](#strict-engineering-standard-no-hardcoded-data)
5. [System Architecture](#system-architecture)
6. [The `/proc` Virtual Filesystem](#the-proc-virtual-filesystem)
7. [Mathematical Calculations & Metric Methodology](#mathematical-calculations--metric-methodology)
   - [CPU Utilization Calculation](#1-cpu-utilization-calculation)
   - [Memory (RAM & Swap) Calculation](#2-memory-ram--swap-calculation)
   - [System Uptime Decomposition](#3-system-uptime-decomposition)
   - [Load Average Interpretation](#4-system-load-average-interpretation)
   - [Process Discovery & State Inspection](#5-process-discovery--state-inspection)
8. [Project Folder Structure](#project-folder-structure)
9. [REST API Documentation](#rest-api-documentation)
10. [Frontend UI/UX Design](#frontend-uiux-design)
11. [Installation & Execution Instructions](#installation--execution-instructions)
    - [Prerequisites](#prerequisites)
    - [Running on Genuine Linux (Ubuntu, Debian, Fedora, Arch)](#running-on-genuine-linux)
    - [Running via Windows Subsystem for Linux (WSL)](#running-via-wsl-windows-subsystem-for-linux)
    - [Running via Docker](#running-via-docker-container)
12. [Testing & Verification](#testing--verification)
13. [Expected Output & UI Preview](#expected-output)
14. [Limitations & Boundary Conditions](#limitations--boundary-conditions)

---

## Project Overview

In Linux operating systems, monitoring kernel state, resource utilization, and running processes is vital for system administrators, performance engineers, and developers. Unlike proprietary operating systems where internal metrics require proprietary APIs or closed-source system calls, the Linux kernel exposes live kernel data structures as readable text files inside the `/proc` virtual filesystem.

This project implements a complete, lightweight, full-stack observability platform consisting of:
- A **Python 3 / Flask** backend that interfaces directly with `/proc` virtual files (`/proc/stat`, `/proc/meminfo`, `/proc/uptime`, `/proc/loadavg`, `/proc/cpuinfo`, `/proc/[PID]/status`).
- A **vanilla HTML5/CSS3/JavaScript** frontend dashboard featuring a high-tech dark sysadmin theme, real-time Chart.js telemetry, dynamic process sorting/searching, and resilient 2.0-second periodic polling.

---

## Problem Statement

Traditional system monitoring tools (such as `top`, `htop`, `vmstat`, or `glances`) run strictly inside terminal environments, which can be difficult for non-technical users to parse or demonstrate visually in an academic presentation. Conversely, many existing web-based projects use hardcoded sample values, random number generators, or heavy enterprise agents (like Datadog or Prometheus) that obscure the foundational operating system concepts.

There is a critical need for a transparent, educational, yet production-grade web dashboard that:
1. Demonstrates direct interaction with the Linux kernel `/proc` filesystem.
2. Derives every single metric mathematically from consecutive kernel counter deltas.
3. Requires zero root/superuser privileges for normal operation.
4. Operates with minimal external dependencies.

---

## Objectives

- **OS Principles**: Demonstrate practical mastery of kernel-space vs. user-space communication, process lifecycle states, virtual filesystems, and scheduling queues.
- **Dynamic Telemetry**: Parse live `/proc` streams and compute true CPU utilization percentages, RAM distribution, and load averages.
- **Process Management**: Safely enumerate process directories (`/proc/[PID]/`), extract process attributes (PID, PPID, State, RSS Memory, Threads), and handle short-lived/terminating processes without crashing.
- **Full-Stack Implementation**: Build a modern, responsive, dark-mode web dashboard refreshing every 2 seconds with request interlocking to prevent overlapping network traffic.

---

## Strict Engineering Standard: No Hardcoded Data

This project adheres to a strict zero-simulation rule:
- **No Mock Numbers**: CPU usage percentages, RAM gigabytes, uptime counters, and load averages are never simulated with random numbers (`random.uniform()`) or hardcoded constants.
- **Dynamic Discovery**: All data is parsed live from the machine hosting the backend.
- **Graceful Non-Linux Notification**: If executed on an operating system without the `/proc` filesystem (e.g., native Windows or macOS), the application cleanly informs the user via the UI alert banner and API health status rather than fabricating fake Linux statistics.

---

## System Architecture

```
+-----------------------------------------------------------------------+
|                           CLIENT BROWSER                              |
|  - Modern Dark SysAdmin Dashboard (HTML5, CSS3, Vanilla JS)           |
|  - Real-Time Chart.js Telemetry (CPU Timeline, RAM Doughnut)           |
|  - Interactive Process Explorer (Search, Sort by PID/RAM, Limit)      |
|  - Periodic Asynchronous Polling (Fetch API every 2000ms)             |
+-----------------------------------^-----------------------------------+
                                    | HTTP / JSON (REST API)
                                    v
+-----------------------------------------------------------------------+
|                      FLASK BACKEND CONTROLLER                         |
|  - REST Endpoints (/api/system, /api/cpu, /api/memory, /api/uptime,   |
|    /api/load, /api/processes, /api/summary, /api/health)              |
|  - Cache Prevention Headers (no-cache, no-store)                      |
|  - Clean Exception & Permission Handling                              |
+-----------------------------------^-----------------------------------+
                                    | Python 3 Modules
                                    v
+-----------------------------------------------------------------------+
|                         MONITORING MODULES                            |
|  - monitors/system_info.py   (/etc/os-release, platform, os.uname)    |
|  - monitors/cpu_monitor.py    (/proc/cpuinfo, /proc/stat)             |
|  - monitors/memory_monitor.py (/proc/meminfo)                         |
|  - monitors/uptime_monitor.py (/proc/uptime)                          |
|  - monitors/load_monitor.py   (/proc/loadavg)                         |
|  - monitors/process_monitor.py(/proc/[PID]/status, comm)              |
+-----------------------------------^-----------------------------------+
                                    | Kernel VFS Reads
                                    v
+=======================================================================+
|                     LINUX KERNEL /proc FILESYSTEM                     |
|  (Dynamic In-Memory Pseudo-Filesystem generated on-the-fly by Kernel)  |
+=======================================================================+
```

---

## The `/proc` Virtual Filesystem

The `/proc` filesystem is a **pseudo-filesystem** (virtual filesystem) created dynamically in memory by the Linux kernel. It does not occupy space on any physical block storage (HDD/SSD). Instead, reading a file in `/proc` triggers a kernel function that queries internal kernel data structures and formats the live state as human-readable ASCII text.

Key virtual files leveraged by this application:
| Virtual File | Kernel Subsystem | Exposed Information |
| :--- | :--- | :--- |
| `/proc/cpuinfo` | CPU Architecture / ACPI | Processor model, clock speed, flags, cache size, core counts |
| `/proc/stat` | CPU Scheduler / Accounting | Cumulative CPU jiffies spent in user, system, idle, iowait, irq |
| `/proc/meminfo` | Memory Subsystem / Slab | Usable RAM, available memory, active/inactive caches, buffers, swap |
| `/proc/uptime` | System Clock / Timer | Monotonic seconds elapsed since machine boot and core idle seconds |
| `/proc/loadavg` | Scheduler Run-Queue | 1, 5, 15 minute moving load averages, runnable threads, last PID |
| `/proc/[PID]/status` | Process Control Block (PCB) | Process name, state (R/S/D/Z/T), PPID, resident set size (VmRSS) |
| `/proc/[PID]/comm` | Task Structure (`task_struct`) | Command executable name (up to 16 characters) |

---

## Mathematical Calculations & Metric Methodology

### 1. CPU Utilization Calculation

The Linux kernel does not provide a single static percentage for CPU utilization. Instead, `/proc/stat` maintains cumulative counters (measured in **USER_HZ**, typically 1/100th of a second or **jiffies**) since system boot:

```
cpu  user nice system idle iowait irq softirq steal guest guest_nice
```

To calculate true instantaneous CPU utilization percentage between time $T_1$ and $T_2$:

1. Compute Total Idle Time:
   $$\text{Idle} = \text{idle} + \text{iowait}$$

2. Compute Total Non-Idle Time:
   $$\text{NonIdle} = \text{user} + \text{nice} + \text{system} + \text{irq} + \text{softirq} + \text{steal}$$

3. Compute Total System Time:
   $$\text{Total} = \text{Idle} + \text{NonIdle}$$

4. Compute the DelTas between two consecutive readings:
   $$\Delta\text{Total} = \text{Total}_2 - \text{Total}_1$$
   $$\Delta\text{Idle} = \text{Idle}_2 - \text{Idle}_1$$

5. Utilization Percentage:
   $$\text{CPU Utilization \%} = \begin{cases} \left(\frac{\Delta\text{Total} - \Delta\text{Idle}}{\Delta\text{Total}}\right) \times 100, & \text{if } \Delta\text{Total} > 0 \\ 0.0, & \text{otherwise} \end{cases}$$

*Handling the First Reading*: On backend startup, `CPUMonitor` captures an initial reading, samples after an immediate 80ms interval to establish baseline deltas, and subsequently compares against the previous poll every 2 seconds without blocking the API.

---

### 2. Memory (RAM & Swap) Calculation

In modern Linux kernels (version $\ge$ 3.14), physical memory utilization is calculated using `MemAvailable`, which accounts for non-reclaimable memory and page caches:

$$\text{Used RAM} = \text{MemTotal} - \text{MemAvailable}$$

For legacy kernels where `MemAvailable` is absent, the fallback formula is applied:
$$\text{Used RAM} = \text{MemTotal} - (\text{MemFree} + \text{Buffers} + \text{Cached})$$

The utilization percentage is:
$$\text{Memory Utilization \%} = \left(\frac{\text{Used RAM}}{\text{MemTotal}}\right) \times 100$$

All quantities are converted dynamically:
$$1\text{ MB} = 1024\text{ kB}, \quad 1\text{ GB} = 1024 \times 1024\text{ kB} = 1,048,576\text{ kB}$$

---

### 3. System Uptime Decomposition

`/proc/uptime` contains two floating-point values:
```
184532.78 738131.12
```
- First value: Total uptime in seconds ($S$).
- Second value: Cumulative core idle time in seconds.

The total seconds $S$ are decomposed using integer division and modulo arithmetic:
$$\text{Days} = \lfloor S / 86400 \rfloor$$
$$\text{Hours} = \lfloor (S \pmod{86400}) / 3600 \rfloor$$
$$\text{Minutes} = \lfloor (S \pmod{3600}) / 60 \rfloor$$
$$\text{Seconds} = \lfloor S \pmod{60} \rfloor$$

---

### 4. System Load Average Interpretation

`/proc/loadavg` provides three exponential moving averages of the scheduler's run-queue length over 1, 5, and 15 minutes:
- On a system with $N$ logical CPU cores:
  - $\text{Load} < N$: Cores have spare execution capacity.
  - $\text{Load} \approx N$: System is running at 100% capacity without backlog.
  - $\text{Load} > N$: Processes are queueing, causing scheduling latency.

---

### 5. Process Discovery & State Inspection

1. The monitor scans `/proc` for directory entries that are purely numeric (`entry.isdigit()`).
2. For each PID directory, `/proc/[PID]/status` is parsed to extract:
   - `Name`: Executable name.
   - `State`: Linux process state character:
     - `R`: Running / Runnable
     - `S`: Sleeping (interruptible wait)
     - `D`: Disk Sleep (uninterruptible I/O wait)
     - `Z`: Zombie (terminated, awaiting parent reap)
     - `T`: Stopped (by signal e.g. SIGSTOP or debugger)
   - `PPid`: Parent process ID.
   - `VmRSS`: Resident Set Size (actual physical RAM occupied by this process).
   - `Threads`: Number of active threads in the thread group.
3. **Resilience**: Because processes are spawned and killed continuously by the kernel, file operations on `/proc/[PID]/` catch `FileNotFoundError`, `ProcessLookupError`, and `PermissionError` cleanly without aborting the scan.

---

## Project Folder Structure

```
linux-system-monitor/
├── app.py                      # Flask REST API server and routing
├── requirements.txt            # Minimal dependencies (Flask)
├── verify_linux_environment.py # Verification runner and environment checker
├── README.md                   # Comprehensive architectural documentation
├── VIVA_QUESTIONS.md           # 25+ OS Viva Examination Questions & Answers
├── monitors/                   # Modular Linux kernel telemetry monitors
│   ├── __init__.py             # Package initializer and exports
│   ├── system_info.py          # OS distro, kernel release, hostname parser
│   ├── cpu_monitor.py          # /proc/cpuinfo and /proc/stat delta calculator
│   ├── memory_monitor.py       # /proc/meminfo RAM & Swap calculator
│   ├── uptime_monitor.py       # /proc/uptime seconds & time decomposition
│   ├── load_monitor.py         # /proc/loadavg run-queue averages
│   └── process_monitor.py      # /proc/[PID]/ process scanner and state tracker
├── templates/
│   └── index.html              # Modern, semantic dashboard layout
├── static/
│   ├── css/
│   │   └── style.css           # Premium dark sysadmin theme & responsive styles
│   └── js/
│       └── dashboard.js        # 2s polling engine, Chart.js, search & sort
└── tests/
    ├── __init__.py
    └── test_monitors.py        # Automated unit test suite (formulas & error handling)
```

---

## REST API Documentation

| Endpoint | Method | Description | Sample Response Fields |
| :--- | :--- | :--- | :--- |
| `GET /` | `GET` | Serves the HTML5 dashboard | HTML document |
| `GET /api/system` | `GET` | Returns OS name, distribution, kernel, architecture | `os_name`, `kernel_version`, `hostname`, `pretty_name` |
| `GET /api/cpu` | `GET` | Dynamic CPU utilization % and hardware metadata | `hardware.model_name`, `hardware.core_count`, `utilization.cpu_utilization_percent`, `utilization.per_core_utilization` |
| `GET /api/memory` | `GET` | RAM and Swap metrics with human-readable units | `total_ram`, `used_ram`, `available_ram`, `memory_utilization_percent`, `swap` |
| `GET /api/uptime` | `GET` | System uptime broken down into days, hours, mins | `formatted_uptime`, `days`, `hours`, `minutes`, `boot_timestamp` |
| `GET /api/load` | `GET` | 1, 5, 15 minute load averages and scheduling counts | `load_1m`, `load_5m`, `load_15m`, `runnable_entities`, `total_scheduling_entities` |
| `GET /api/processes` | `GET` | Real running processes from `/proc/[PID]/` | `total_processes`, `state_summary`, `processes: [{pid, name, state, ppid, memory_rss_mb}]` |
| `GET /api/summary` | `GET` | Consolidated payload of all telemetry (single round-trip) | Combined JSON payload for low-latency 2s polling |
| `GET /api/health` | `GET` | Health check and Linux `/proc` compatibility verification | `status: "healthy"`, `has_proc_filesystem: true/false` |

---

## Frontend UI/UX Design

The dashboard incorporates modern observability interface standards:
- **Theme**: Deep slate background (`#0a0e17`) with cyan, emerald, purple, and amber telemetry accents.
- **Header**: Pulsing live status indicator, dynamic polling interval label (`2.0s`), last updated timestamp, and interactive pause/resume toggle.
- **CPU Telemetry Card**: Model name, core count, utilization gauge with dynamic color thresholding (<50% green, 50–85% amber, >85% red), per-core mini bars, and a real-time historical Chart.js line graph.
- **Memory Telemetry Card**: Total, Used, Available, Free, Buffers/Cache breakdown, dynamic progress bar, Swap details, and a Chart.js doughnut chart.
- **Load Average Card**: 1m, 5m, 15m load gauges with color-coded comparison against total CPU cores.
- **Process Explorer**:
  - Live search input matching PID or process name instantly.
  - Row limit selector (`25`, `50`, `100`, `All`).
  - Column sorting (PID, Name, State, PPID, Memory, Threads) with directional arrows.
  - Color-coded state badges (Running, Sleeping, Zombie, Stopped).

---

## Installation & Execution Instructions

### Prerequisites
- Python 3.8 or higher.
- `pip` package manager.

### Running on Genuine Linux
*(Ubuntu, Debian, Fedora, CentOS, Arch, openSUSE, etc.)*

```bash
# 1. Clone or navigate to the project directory
cd linux-system-monitor

# 2. (Optional but recommended) Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the automated verification script
python3 verify_linux_environment.py

# 5. Start the monitoring web server
python3 app.py
```
Open your browser at: **`http://localhost:5000`**

---

### Running via WSL (Windows Subsystem for Linux)
*(WSL provides a genuine Linux kernel running inside Windows)*

```bash
# 1. Open PowerShell and launch WSL
wsl

# 2. Navigate to the Windows scratch project directory from within Linux
cd /mnt/c/Users/DELL/.gemini/antigravity/scratch/linux-system-monitor

# 3. Install Flask inside WSL
sudo apt update && sudo apt install -y python3-pip
pip3 install -r requirements.txt

# 4. Launch the application
python3 app.py
```
Open **`http://localhost:5000`** in Windows Chrome/Edge/Firefox. The backend will read genuine Linux metrics directly from WSL's Linux kernel `/proc` filesystem!

---

### Running via Docker Container

```bash
# Run with host /proc mounted read-only
docker run -d \
  --name linux-monitor \
  -p 5000:5000 \
  -v /proc:/proc:ro \
  python:3.11-slim \
  bash -c "pip install flask && cd /app && python app.py"
```

---

## Testing & Verification

The project includes an automated test suite verifying mathematical formulas, boundary conditions, zero-delta states, and status parsers:

```bash
# Run the test suite
python3 -m unittest discover tests -v
```

Test Cases Covered:
1. `test_cpu_formula_exact_delta`: Verifies utilization percentage matches manual mathematical formula.
2. `test_cpu_zero_delta`: Guarantees zero elapsed time does not cause division-by-zero errors.
3. `test_cpuinfo_parsing_with_mock_file`: Verifies parsing of multi-processor CPU info blocks.
4. `test_memory_formula_modern_kernel`: Verifies `MemTotal - MemAvailable` calculation.
5. `test_memory_formula_legacy_fallback`: Verifies fallback for older kernels.
6. `test_byte_formatting`: Validates conversions between kB, MB, and GB.
7. `test_uptime_parsing`: Verifies exact decomposition into days, hours, minutes, and seconds.
8. `test_load_parsing`: Verifies 1m, 5m, 15m load averages and thread counters.
9. `test_parse_valid_status_file`: Validates process name, state, PPID, and RSS memory parsing.
10. `test_nonexistent_process_dir`: Validates graceful handling of terminated processes.

---

## Expected Output

When running on genuine Linux / WSL:
- **System Overview**: Displays distribution name (e.g. `Ubuntu 22.04 LTS`), Linux kernel version (e.g. `5.15.0-generic`), hostname, and active uptime.
- **CPU Telemetry**: Shows live processor model, dynamic CPU % updating every 2 seconds, and active historical line graph.
- **Memory Telemetry**: Visualizes exact RAM utilization and doughnut distribution.
- **Load Averages**: Updates 1m, 5m, and 15m run-queue measurements.
- **Processes**: Populates live table with real running system processes, PIDs, and memory footprints.

When running on Windows:
- The top alert banner informs the operator that the `/proc` filesystem is absent on the host OS.
- In strict adherence to Rule #2, no fake mock data is displayed, and instructions to run on Linux/WSL are provided.

---

## Limitations & Boundary Conditions

1. **Operating System Requirement**: Designed specifically for the Linux kernel architecture (`/proc`). macOS and Windows (outside WSL) do not provide `/proc` and will trigger the non-Linux environment state.
2. **Permission Boundary**: The application runs entirely in unprivileged user space. It does not inspect root-only kernel files or require `sudo`. Certain process memory fields for root daemons might be masked by the kernel for unprivileged users.
3. **Containerized Environments**: In restricted Docker containers without host PID namespace sharing (`--pid=host`), only container-local processes will be visible in the process table.

---

**Developed for Operating Systems Continuous Comprehensive Assessment (CCA).**
