"""
System Uptime Monitor
Retrieves system uptime and core idle time from /proc/uptime,
formatting values dynamically into days, hours, minutes, and seconds.
"""

import os
import time
from datetime import datetime, timezone
from typing import Dict, Any


def get_uptime_info(uptime_path: str = "/proc/uptime") -> Dict[str, Any]:
    """
    Parses /proc/uptime to extract:
    1. Total uptime in seconds.
    2. Aggregate CPU idle time across all cores.
    3. Formatted breakdown into days, hours, minutes, and seconds.
    4. Exact system boot timestamp.
    """
    if not os.path.exists(uptime_path):
        return {
            "supported": False,
            "error": f"{uptime_path} not found. Linux /proc filesystem required.",
        }

    try:
        with open(uptime_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read().strip()
            parts = content.split()
            if len(parts) < 1:
                return {
                    "supported": False,
                    "error": f"Invalid format in {uptime_path}",
                }
            uptime_seconds = float(parts[0])
            idle_seconds = float(parts[1]) if len(parts) > 1 else 0.0
    except (OSError, IOError, ValueError) as e:
        return {
            "supported": False,
            "error": f"Error reading {uptime_path}: {str(e)}",
        }

    total_sec = int(uptime_seconds)
    days = total_sec // 86400
    rem = total_sec % 86400
    hours = rem // 3600
    rem = rem % 3600
    minutes = rem // 60
    seconds = rem % 60

    # Human-readable representation
    components = []
    if days > 0:
        components.append(f"{days} day{'s' if days != 1 else ''}")
    if hours > 0 or days > 0:
        components.append(f"{hours} hour{'s' if hours != 1 else ''}")
    if minutes > 0 or hours > 0 or days > 0:
        components.append(f"{minutes} min{'s' if minutes != 1 else ''}")
    components.append(f"{seconds} sec{'s' if seconds != 1 else ''}")

    formatted_str = ", ".join(components)

    # Compute boot timestamp
    current_ts = time.time()
    boot_ts = current_ts - uptime_seconds
    boot_time_iso = datetime.fromtimestamp(boot_ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    return {
        "supported": True,
        "total_seconds": round(uptime_seconds, 2),
        "days": days,
        "hours": hours,
        "minutes": minutes,
        "seconds": seconds,
        "formatted_uptime": formatted_str,
        "boot_timestamp": boot_time_iso,
        "idle_cpu_seconds": round(idle_seconds, 2),
    }
