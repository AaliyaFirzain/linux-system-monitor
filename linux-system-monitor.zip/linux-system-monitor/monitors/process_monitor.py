"""
Process Monitoring Module
Dynamically inspects numeric directories in /proc/[PID]/ to discover real Linux processes,
reading process states, parent PIDs, memory usage, and command names safely without root.
Handles transient, short-lived, or permission-protected processes reliably.
"""

import os
from typing import Dict, Any, List, Optional


STATE_MAP = {
    "R": "Running",
    "S": "Sleeping",
    "D": "Disk Sleep (Uninterruptible)",
    "Z": "Zombie",
    "T": "Stopped",
    "t": "Tracing Stop",
    "X": "Dead",
    "I": "Idle (Kernel)",
}


def parse_process_status(pid_dir: str) -> Optional[Dict[str, Any]]:
    """
    Reads /proc/[PID]/status to extract process metadata.
    Catches FileNotFoundError, ProcessLookupError, and PermissionError gracefully.
    """
    status_file = os.path.join(pid_dir, "status")
    if not os.path.exists(status_file):
        return None

    name = ""
    state_raw = ""
    ppid = 0
    vm_rss_kb = 0
    vm_size_kb = 0
    threads = 1

    try:
        with open(status_file, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                parts = line.strip().split(":", 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    val = parts[1].strip()
                    if key == "Name":
                        name = val
                    elif key == "State":
                        state_raw = val
                    elif key == "PPid":
                        try:
                            ppid = int(val)
                        except ValueError:
                            ppid = 0
                    elif key == "VmRSS":
                        val_parts = val.split()
                        if val_parts:
                            try:
                                vm_rss_kb = int(val_parts[0])
                            except ValueError:
                                pass
                    elif key == "VmSize":
                        val_parts = val.split()
                        if val_parts:
                            try:
                                vm_size_kb = int(val_parts[0])
                            except ValueError:
                                pass
                    elif key == "Threads":
                        try:
                            threads = int(val)
                        except ValueError:
                            threads = 1
    except (FileNotFoundError, ProcessLookupError, PermissionError, OSError):
        # The process was terminated or is inaccessible
        return None

    # Determine state letter and friendly label
    state_char = state_raw.split()[0] if state_raw else "U"
    state_desc = STATE_MAP.get(state_char, state_raw if state_raw else "Unknown")

    # Format memory in MB
    rss_mb = round(vm_rss_kb / 1024.0, 2)

    return {
        "name": name if name else "unknown",
        "state_char": state_char,
        "state_desc": state_desc,
        "ppid": ppid,
        "vm_rss_kb": vm_rss_kb,
        "vm_rss_mb": rss_mb,
        "vm_size_kb": vm_size_kb,
        "threads": threads,
    }


def get_processes_info(
    proc_root: str = "/proc",
    search: Optional[str] = None,
    sort_by: str = "pid",
    ascending: bool = True,
    limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Scans /proc for all running processes.
    Aggregates process counts, state distribution, and per-process details.
    """
    if not os.path.exists(proc_root):
        return {
            "supported": False,
            "error": f"{proc_root} not found. Linux /proc filesystem required.",
            "total_count": 0,
            "processes": [],
        }

    processes: List[Dict[str, Any]] = []
    state_counts = {
        "running": 0,
        "sleeping": 0,
        "zombie": 0,
        "stopped": 0,
        "other": 0,
    }

    try:
        entries = os.listdir(proc_root)
    except (OSError, IOError) as e:
        return {
            "supported": False,
            "error": f"Failed reading {proc_root}: {str(e)}",
            "total_count": 0,
            "processes": [],
        }

    # Iterate over numeric PID directories
    for entry in entries:
        if not entry.isdigit():
            continue

        pid = int(entry)
        pid_dir = os.path.join(proc_root, entry)
        proc_info = parse_process_status(pid_dir)
        if proc_info is None:
            # Process terminated or inaccessible
            continue

        # Update state counts
        s_char = proc_info["state_char"]
        if s_char == "R":
            state_counts["running"] += 1
        elif s_char in ("S", "I", "D"):
            state_counts["sleeping"] += 1
        elif s_char == "Z":
            state_counts["zombie"] += 1
        elif s_char in ("T", "t"):
            state_counts["stopped"] += 1
        else:
            state_counts["other"] += 1

        proc_entry = {
            "pid": pid,
            "name": proc_info["name"],
            "state_char": s_char,
            "state": proc_info["state_desc"],
            "ppid": proc_info["ppid"],
            "memory_rss_kb": proc_info["vm_rss_kb"],
            "memory_rss_mb": proc_info["vm_rss_mb"],
            "threads": proc_info["threads"],
        }

        # Apply search filter if provided
        if search:
            query = search.lower().strip()
            if query not in str(pid) and query not in proc_entry["name"].lower():
                continue

        processes.append(proc_entry)

    total_detected = len(processes)

    # Sort processes
    if sort_by == "memory":
        processes.sort(key=lambda p: p["memory_rss_kb"], reverse=not ascending)
    elif sort_by == "name":
        processes.sort(key=lambda p: p["name"].lower(), reverse=not ascending)
    elif sort_by == "ppid":
        processes.sort(key=lambda p: p["ppid"], reverse=not ascending)
    else:
        # Default sort by PID
        processes.sort(key=lambda p: p["pid"], reverse=not ascending)

    # Apply pagination/limit if requested
    returned_processes = processes[:limit] if limit and limit > 0 else processes

    return {
        "supported": True,
        "total_processes": total_detected,
        "state_summary": state_counts,
        "returned_count": len(returned_processes),
        "processes": returned_processes,
    }
