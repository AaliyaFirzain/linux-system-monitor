/**
 * Linux System Information Monitor - Frontend Dashboard Controller
 * Handles 2-second periodic polling, Chart.js updates, table sorting/filtering,
 * and robust error management without any mock data generation.
 */

(function () {
    'use strict';

    // Application State
    const STATE = {
        pollIntervalMs: 2000,
        timerId: null,
        isPollingActive: true,
        isRequestInProgress: false,
        cachedProcesses: [],
        currentSort: { column: 'pid', ascending: true },
        searchQuery: '',
        rowLimit: 50,
        cpuHistory: { labels: [], data: [] },
        maxHistoryPoints: 25,
        charts: { cpu: null, mem: null },
    };

    // DOM Element References
    const DOM = {
        statusIndicator: document.getElementById('connection-status'),
        statusText: document.getElementById('status-text'),
        lastUpdatedTime: document.getElementById('last-updated-time'),
        pollIntervalLabel: document.getElementById('poll-interval-label'),
        btnToggleRefresh: document.getElementById('btn-toggle-refresh'),
        iconPause: document.getElementById('icon-pause'),
        iconPlay: document.getElementById('icon-play'),
        envAlertBanner: document.getElementById('env-alert-banner'),
        alertTitle: document.getElementById('alert-title'),
        alertMessage: document.getElementById('alert-message'),
        
        // System Overview
        valOsName: document.getElementById('val-os-name'),
        valDistro: document.getElementById('val-distro'),
        valKernel: document.getElementById('val-kernel'),
        valHostname: document.getElementById('val-hostname'),
        valArch: document.getElementById('val-arch'),
        valUptime: document.getElementById('val-uptime'),
        valBootTime: document.getElementById('val-boot-time'),

        // CPU
        valCpuModel: document.getElementById('val-cpu-model'),
        valCpuPct: document.getElementById('val-cpu-pct'),
        cpuProgressBar: document.getElementById('cpu-progress-bar'),
        valCpuCores: document.getElementById('val-cpu-cores'),
        valCpuClock: document.getElementById('val-cpu-clock'),
        coresGrid: document.getElementById('cores-grid'),
        cpuCanvas: document.getElementById('cpuChart'),

        // Memory
        valMemPct: document.getElementById('val-mem-pct'),
        memProgressBar: document.getElementById('mem-progress-bar'),
        valMemUsed: document.getElementById('val-mem-used'),
        valMemTotal: document.getElementById('val-mem-total'),
        valMemAvail: document.getElementById('val-mem-avail'),
        valMemFree: document.getElementById('val-mem-free'),
        valMemCached: document.getElementById('val-mem-cached'),
        valSwapUsed: document.getElementById('val-swap-used'),
        memCanvas: document.getElementById('memChart'),

        // Load
        valLoad1m: document.getElementById('val-load-1m'),
        valLoad5m: document.getElementById('val-load-5m'),
        valLoad15m: document.getElementById('val-load-15m'),
        loadStatusBadge: document.getElementById('load-status-badge'),
        valSchedThreads: document.getElementById('val-sched-threads'),
        valLastPid: document.getElementById('val-last-pid'),

        // Processes
        cntTotal: document.getElementById('cnt-total'),
        cntRunning: document.getElementById('cnt-running'),
        cntSleeping: document.getElementById('cnt-sleeping'),
        cntZombie: document.getElementById('cnt-zombie'),
        procSearchInput: document.getElementById('proc-search-input'),
        btnClearSearch: document.getElementById('btn-clear-search'),
        selectProcLimit: document.getElementById('select-proc-limit'),
        btnRefreshProc: document.getElementById('btn-refresh-proc'),
        processTbody: document.getElementById('process-tbody'),
        footerConnectionMsg: document.getElementById('footer-connection-msg'),
    };

    /**
     * Initializes real-time Chart.js instances.
     */
    function initCharts() {
        // CPU Utilization History Line Chart
        if (DOM.cpuCanvas && typeof Chart !== 'undefined') {
            const ctxCpu = DOM.cpuCanvas.getContext('2d');
            STATE.charts.cpu = new Chart(ctxCpu, {
                type: 'line',
                data: {
                    labels: STATE.cpuHistory.labels,
                    datasets: [{
                        label: 'CPU Usage %',
                        data: STATE.cpuHistory.data,
                        borderColor: '#00f0ff',
                        backgroundColor: 'rgba(0, 240, 255, 0.1)',
                        borderWidth: 2,
                        pointRadius: 0,
                        tension: 0.35,
                        fill: true,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    animation: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            backgroundColor: '#111827',
                            borderColor: '#1f293d',
                            borderWidth: 1,
                        }
                    },
                    scales: {
                        x: { display: false },
                        y: {
                            min: 0,
                            max: 100,
                            grid: { color: 'rgba(255, 255, 255, 0.05)' },
                            ticks: {
                                color: '#64748b',
                                font: { family: 'JetBrains Mono', size: 10 },
                                stepSize: 25,
                                callback: (v) => `${v}%`
                            }
                        }
                    }
                }
            });
        }

        // Memory Distribution Doughnut Chart
        if (DOM.memCanvas && typeof Chart !== 'undefined') {
            const ctxMem = DOM.memCanvas.getContext('2d');
            STATE.charts.mem = new Chart(ctxMem, {
                type: 'doughnut',
                data: {
                    labels: ['Used RAM', 'Cached/Buffers', 'Free RAM'],
                    datasets: [{
                        data: [0, 0, 100],
                        backgroundColor: ['#8b5cf6', '#3b82f6', '#10b981'],
                        borderColor: '#111827',
                        borderWidth: 2,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: {
                                color: '#94a3b8',
                                font: { family: 'Inter', size: 11 },
                                boxWidth: 12,
                                padding: 8,
                            }
                        },
                        tooltip: {
                            backgroundColor: '#111827',
                            borderColor: '#1f293d',
                            borderWidth: 1,
                        }
                    }
                }
            });
        }
    }

    /**
     * Updates the status badge and footer message.
     */
    function updateStatus(status, label) {
        DOM.statusIndicator.className = 'status-indicator ' + status;
        DOM.statusText.textContent = label;
    }

    /**
     * Updates System Overview Card.
     */
    function updateSystemOverview(sys, uptime) {
        if (!sys) return;

        if (sys.supported) {
            DOM.valOsName.textContent = sys.os_name || 'Linux';
            DOM.valDistro.textContent = sys.pretty_name || sys.distribution_name || 'Generic Linux';
            DOM.valKernel.textContent = sys.kernel_version || '--';
            DOM.valHostname.textContent = sys.hostname || '--';
            DOM.valArch.textContent = `Arch: ${sys.machine_architecture || '--'}`;
        } else {
            DOM.valOsName.textContent = sys.current_os || 'Non-Linux';
            DOM.valDistro.textContent = 'Not Supported';
            DOM.valKernel.textContent = sys.current_release || '--';
            DOM.valHostname.textContent = sys.hostname || '--';
            DOM.valArch.textContent = `Arch: ${sys.architecture || '--'}`;
        }

        if (uptime && uptime.supported) {
            DOM.valUptime.textContent = uptime.formatted_uptime || '--';
            DOM.valBootTime.textContent = `Booted: ${uptime.boot_timestamp || '--'}`;
        } else if (uptime && !uptime.supported) {
            DOM.valUptime.textContent = 'N/A (/proc/uptime missing)';
            DOM.valBootTime.textContent = 'Booted: Genuine Linux required';
        }
    }

    /**
     * Updates CPU Monitoring Card and Charts.
     */
    function updateCpu(cpu) {
        if (!cpu) return;

        if (!cpu.supported) {
            DOM.valCpuPct.textContent = '0.0';
            DOM.cpuProgressBar.style.width = '0%';
            DOM.valCpuModel.textContent = cpu.hardware?.model_name || 'Genuine Linux required';
            DOM.valCpuCores.textContent = `Cores: ${cpu.hardware?.core_count || '--'}`;
            return;
        }

        const hw = cpu.hardware || {};
        const ut = cpu.utilization || {};
        const pct = ut.cpu_utilization_percent || 0.0;

        DOM.valCpuModel.textContent = hw.model_name || 'Unknown Processor';
        DOM.valCpuPct.textContent = pct.toFixed(1);
        DOM.cpuProgressBar.style.width = `${Math.min(100, Math.max(0, pct))}%`;

        // Color coding based on utilization thresholds
        if (pct >= 85) {
            DOM.cpuProgressBar.className = 'progress-bar-fill high';
        } else {
            DOM.cpuProgressBar.className = 'progress-bar-fill';
        }

        DOM.valCpuCores.textContent = `Cores: ${hw.core_count || 1}`;
        DOM.valCpuClock.textContent = hw.cpu_mhz && hw.cpu_mhz !== 'Unknown' ? `${hw.cpu_mhz} MHz` : 'Dynamic';

        // Render per-core mini bars
        const perCore = ut.per_core_utilization || {};
        const coreKeys = Object.keys(perCore);
        if (coreKeys.length > 0) {
            DOM.coresGrid.innerHTML = '';
            coreKeys.forEach((key, idx) => {
                const corePct = perCore[key] || 0.0;
                const coreDiv = document.createElement('div');
                coreDiv.className = 'core-item';
                coreDiv.innerHTML = `
                    <div class="core-name">C${idx}</div>
                    <div class="core-bar-bg">
                        <div class="core-bar-fill" style="width: ${Math.min(100, corePct)}%"></div>
                    </div>
                    <div class="core-pct">${Math.round(corePct)}%</div>
                `;
                DOM.coresGrid.appendChild(coreDiv);
            });
        }

        // Update CPU Chart.js history
        if (STATE.charts.cpu) {
            const timeLabel = new Date().toLocaleTimeString();
            STATE.cpuHistory.labels.push(timeLabel);
            STATE.cpuHistory.data.push(pct);

            if (STATE.cpuHistory.labels.length > STATE.maxHistoryPoints) {
                STATE.cpuHistory.labels.shift();
                STATE.cpuHistory.data.shift();
            }

            STATE.charts.cpu.update('none'); // Update without full redraw
        }
    }

    /**
     * Updates Memory Monitoring Card and Doughnut Chart.
     */
    function updateMemory(mem) {
        if (!mem) return;

        if (!mem.supported) {
            DOM.valMemPct.textContent = '0.0';
            DOM.memProgressBar.style.width = '0%';
            DOM.valMemUsed.textContent = '--';
            DOM.valMemTotal.textContent = '--';
            DOM.valMemAvail.textContent = 'N/A';
            DOM.valMemFree.textContent = 'N/A';
            DOM.valMemCached.textContent = 'N/A';
            DOM.valSwapUsed.textContent = 'N/A';
            return;
        }

        const pct = mem.memory_utilization_percent || 0.0;
        DOM.valMemPct.textContent = pct.toFixed(1);
        DOM.memProgressBar.style.width = `${Math.min(100, Math.max(0, pct))}%`;

        DOM.valMemUsed.textContent = mem.used_ram?.formatted || '--';
        DOM.valMemTotal.textContent = mem.total_ram?.formatted || '--';
        DOM.valMemAvail.textContent = mem.available_ram?.formatted || '--';
        DOM.valMemFree.textContent = mem.free_ram?.formatted || '--';

        const buffersMb = (mem.buffers?.mb || 0) + (mem.cached?.mb || 0);
        DOM.valMemCached.textContent = `${Math.round(buffersMb)} MB`;

        if (mem.swap) {
            DOM.valSwapUsed.textContent = `${mem.swap.used?.formatted || '0 MB'} (${mem.swap.utilization_percent || 0}%)`;
        }

        // Update Memory Doughnut Chart
        if (STATE.charts.mem) {
            const usedMb = mem.used_ram?.mb || 0;
            const cachedMb = buffersMb;
            const freeMb = mem.free_ram?.mb || 0;

            STATE.charts.mem.data.datasets[0].data = [usedMb, cachedMb, freeMb];
            STATE.charts.mem.update();
        }
    }

    /**
     * Updates System Load Average Card.
     */
    function updateLoad(load, cpu) {
        if (!load || !load.supported) {
            DOM.valLoad1m.textContent = '0.00';
            DOM.valLoad5m.textContent = '0.00';
            DOM.valLoad15m.textContent = '0.00';
            DOM.loadStatusBadge.textContent = 'N/A';
            DOM.valSchedThreads.textContent = '-- / --';
            DOM.valLastPid.textContent = '--';
            return;
        }

        const l1 = load.load_1m || 0.0;
        const l5 = load.load_5m || 0.0;
        const l15 = load.load_15m || 0.0;

        DOM.valLoad1m.textContent = l1.toFixed(2);
        DOM.valLoad5m.textContent = l5.toFixed(2);
        DOM.valLoad15m.textContent = l15.toFixed(2);

        DOM.valSchedThreads.textContent = `${load.runnable_entities || 0} runnable / ${load.total_scheduling_entities || 0} total`;
        DOM.valLastPid.textContent = load.last_created_pid ? `#${load.last_created_pid}` : '--';

        // Load relative to CPU core count
        const cores = (cpu && cpu.hardware && cpu.hardware.core_count) ? cpu.hardware.core_count : 1;
        if (l1 <= cores) {
            DOM.loadStatusBadge.textContent = 'Normal Load';
            DOM.loadStatusBadge.style.background = 'rgba(16, 185, 129, 0.15)';
            DOM.loadStatusBadge.style.color = '#10b981';
            DOM.loadStatusBadge.style.borderColor = 'rgba(16, 185, 129, 0.3)';
        } else if (l1 <= cores * 1.5) {
            DOM.loadStatusBadge.textContent = 'Elevated Load';
            DOM.loadStatusBadge.style.background = 'rgba(245, 158, 11, 0.15)';
            DOM.loadStatusBadge.style.color = '#f59e0b';
            DOM.loadStatusBadge.style.borderColor = 'rgba(245, 158, 11, 0.3)';
        } else {
            DOM.loadStatusBadge.textContent = 'Heavy Load';
            DOM.loadStatusBadge.style.background = 'rgba(239, 68, 68, 0.15)';
            DOM.loadStatusBadge.style.color = '#ef4444';
            DOM.loadStatusBadge.style.borderColor = 'rgba(239, 68, 68, 0.3)';
        }
    }

    /**
     * Updates Process Explorer Table and State Counts.
     */
    function updateProcesses(procData) {
        if (!procData) return;

        if (!procData.supported) {
            DOM.cntTotal.textContent = '0';
            DOM.cntRunning.textContent = '0';
            DOM.cntSleeping.textContent = '0';
            DOM.cntZombie.textContent = '0';
            DOM.processTbody.innerHTML = `
                <tr>
                    <td colspan="6" class="loading-cell" style="color: #ef4444;">
                        /proc filesystem not accessible. Genuine Linux runtime required to list active processes.
                    </td>
                </tr>
            `;
            return;
        }

        const counts = procData.state_summary || {};
        DOM.cntTotal.textContent = procData.total_processes || 0;
        DOM.cntRunning.textContent = counts.running || 0;
        DOM.cntSleeping.textContent = counts.sleeping || 0;
        DOM.cntZombie.textContent = counts.zombie || 0;

        STATE.cachedProcesses = procData.processes || [];
        renderProcessTable();
    }

    /**
     * Renders filtered, sorted processes into the table.
     */
    function renderProcessTable() {
        let procs = [...STATE.cachedProcesses];

        // Search filter
        if (STATE.searchQuery) {
            const q = STATE.searchQuery.toLowerCase();
            procs = procs.filter(p => 
                String(p.pid).includes(q) || 
                (p.name && p.name.toLowerCase().includes(q))
            );
        }

        // Sort
        const col = STATE.currentSort.column;
        const asc = STATE.currentSort.ascending;

        procs.sort((a, b) => {
            let vA = a[col];
            let vB = b[col];

            if (col === 'memory') {
                vA = a.memory_rss_kb || 0;
                vB = b.memory_rss_kb || 0;
            } else if (col === 'name') {
                vA = (a.name || '').toLowerCase();
                vB = (b.name || '').toLowerCase();
            }

            if (vA < vB) return asc ? -1 : 1;
            if (vA > vB) return asc ? 1 : -1;
            return 0;
        });

        // Limit
        if (STATE.rowLimit !== 'all') {
            const limit = parseInt(STATE.rowLimit, 10);
            if (!isNaN(limit)) {
                procs = procs.slice(0, limit);
            }
        }

        if (procs.length === 0) {
            DOM.processTbody.innerHTML = `
                <tr>
                    <td colspan="6" class="loading-cell">No matching processes found.</td>
                </tr>
            `;
            return;
        }

        const rowsHtml = procs.map(p => {
            const stateChar = p.state_char || 'S';
            const stateLabel = p.state || stateChar;
            const memFormatted = p.memory_rss_mb > 0 
                ? `${p.memory_rss_mb.toFixed(1)} MB` 
                : `${p.memory_rss_kb || 0} kB`;

            return `
                <tr>
                    <td class="cell-pid">${p.pid}</td>
                    <td class="cell-name">${escapeHtml(p.name)}</td>
                    <td>
                        <span class="state-badge state-${stateChar}">${stateChar} (${stateLabel})</span>
                    </td>
                    <td class="cell-ppid">${p.ppid}</td>
                    <td class="cell-mem">${memFormatted}</td>
                    <td class="cell-threads">${p.threads || 1}</td>
                </tr>
            `;
        }).join('');

        DOM.processTbody.innerHTML = rowsHtml;
    }

    /**
     * Helper to safely escape HTML.
     */
    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>"']/g, function(m) {
            switch (m) {
                case '&': return '&amp;';
                case '<': return '&lt;';
                case '>': return '&gt;';
                case '"': return '&quot;';
                case "'": return '&#39;';
            }
        });
    }

    /**
     * Primary polling function. Fetches /api/summary.
     */
    async function fetchSystemMetrics() {
        if (STATE.isRequestInProgress || !STATE.isPollingActive) {
            return;
        }

        STATE.isRequestInProgress = true;
        const startTime = Date.now();

        try {
            const response = await fetch('/api/summary', { cache: 'no-store' });
            if (!response.ok) {
                throw new Error(`HTTP error ${response.status}`);
            }

            const data = await response.json();
            const latency = Date.now() - startTime;

            // Check Linux support
            const hasProc = data.system && data.system.supported;
            if (!hasProc) {
                DOM.envAlertBanner.classList.remove('hidden');
                updateStatus('paused', 'NON-LINUX DETECTED');
                DOM.footerConnectionMsg.textContent = `Backend online (${latency}ms) &bull; /proc missing on current OS`;
            } else {
                DOM.envAlertBanner.classList.add('hidden');
                updateStatus('live', 'LIVE MONITORING');
                DOM.footerConnectionMsg.textContent = `Connected &bull; Polling every 2.0s &bull; Latency: ${latency}ms`;
            }

            // Update components
            updateSystemOverview(data.system, data.uptime);
            updateCpu(data.cpu);
            updateMemory(data.memory);
            updateLoad(data.load, data.cpu);
            updateProcesses(data.processes);

            // Update timestamp
            DOM.lastUpdatedTime.textContent = new Date().toLocaleTimeString();

        } catch (err) {
            console.error('Metrics fetch failed:', err);
            updateStatus('error', 'CONNECTION ERROR');
            DOM.footerConnectionMsg.textContent = `API disconnected: ${err.message}. Retrying in 2s...`;
        } finally {
            STATE.isRequestInProgress = false;
        }
    }

    /**
     * Toggles polling state between running and paused.
     */
    function togglePolling() {
        STATE.isPollingActive = !STATE.isPollingActive;
        if (STATE.isPollingActive) {
            DOM.iconPause.classList.remove('hidden');
            DOM.iconPlay.classList.add('hidden');
            updateStatus('live', 'LIVE MONITORING');
            fetchSystemMetrics();
        } else {
            DOM.iconPause.classList.add('hidden');
            DOM.iconPlay.classList.remove('hidden');
            updateStatus('paused', 'PAUSED');
        }
    }

    /**
     * Sets up event listeners for search, sort, and toolbar controls.
     */
    function setupEventListeners() {
        // Pause/Play Button
        DOM.btnToggleRefresh.addEventListener('click', togglePolling);

        // Search Input
        DOM.procSearchInput.addEventListener('input', (e) => {
            STATE.searchQuery = e.target.value.trim();
            if (STATE.searchQuery) {
                DOM.btnClearSearch.classList.remove('hidden');
            } else {
                DOM.btnClearSearch.classList.add('hidden');
            }
            renderProcessTable();
        });

        // Clear Search
        DOM.btnClearSearch.addEventListener('click', () => {
            DOM.procSearchInput.value = '';
            STATE.searchQuery = '';
            DOM.btnClearSearch.classList.add('hidden');
            renderProcessTable();
        });

        // Row Limit Select
        DOM.selectProcLimit.addEventListener('change', (e) => {
            STATE.rowLimit = e.target.value;
            renderProcessTable();
        });

        // Manual Refresh Button
        DOM.btnRefreshProc.addEventListener('click', () => {
            fetchSystemMetrics();
        });

        // Table Header Sorting
        const sortHeaders = document.querySelectorAll('.process-table th.sortable');
        sortHeaders.forEach(th => {
            th.addEventListener('click', () => {
                const column = th.getAttribute('data-sort');
                if (STATE.currentSort.column === column) {
                    STATE.currentSort.ascending = !STATE.currentSort.ascending;
                } else {
                    STATE.currentSort.column = column;
                    STATE.currentSort.ascending = true;
                }

                // Update visual arrows
                sortHeaders.forEach(header => {
                    header.classList.remove('active-sort');
                    const arrow = header.querySelector('.sort-arrow');
                    if (arrow) arrow.innerHTML = '';
                });

                th.classList.add('active-sort');
                const arrow = th.querySelector('.sort-arrow');
                if (arrow) {
                    arrow.innerHTML = STATE.currentSort.ascending ? '&uarr;' : '&darr;';
                }

                renderProcessTable();
            });
        });
    }

    /**
     * Application Entry Point.
     */
    function init() {
        initCharts();
        setupEventListeners();
        fetchSystemMetrics(); // Initial fetch
        STATE.timerId = setInterval(fetchSystemMetrics, STATE.pollIntervalMs);
    }

    // Launch on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
