"""
Unit & Integration Test Suite for Linux System Information Monitor
Tests mathematical formulas, /proc parsing logic, boundary conditions,
error handling, and REST API endpoints using Python's standard unittest.
"""

import os
import sys
import tempfile
import unittest

# Ensure parent directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from monitors.system_info import parse_os_release, get_system_info
from monitors.cpu_monitor import CPUMonitor
from monitors.memory_monitor import parse_meminfo, get_memory_info, format_bytes
from monitors.uptime_monitor import get_uptime_info
from monitors.load_monitor import get_load_info
from monitors.process_monitor import parse_process_status, get_processes_info
try:
    import flask
    from app import app
    HAS_FLASK = True
except ImportError:
    HAS_FLASK = False
    app = None


class TestCPUCalculations(unittest.TestCase):
    """Verifies CPU utilization calculations and boundary conditions."""

    def test_cpu_formula_exact_delta(self):
        # Baseline: idle=1000, total=5000
        prev = (1000, 5000)
        # Next reading: user=1800, nice=0, system=1000, idle=1500, iowait=100, irq=100, softirq=100, steal=0
        # idle_all = 1500 + 100 = 1600. Delta idle = 1600 - 1000 = 600.
        # non_idle = 1800 + 0 + 1000 + 100 + 100 + 0 = 3000.
        # total = 1600 + 3000 = 4600. Wait, let's make total higher than 5000:
        # user=2800, nice=0, system=1000, idle=1800, iowait=200, irq=100, softirq=100, steal=0
        # idle_all = 1800 + 200 = 2000. Delta idle = 2000 - 1000 = 1000.
        # non_idle = 2800 + 0 + 1000 + 100 + 100 = 4000.
        # total = 2000 + 4000 = 6000. Delta total = 6000 - 5000 = 1000.
        # Usage = ((1000 - 1000) / 1000) * 100 = 0.0%
        curr_stats = [2800, 0, 1000, 1800, 200, 100, 100, 0]
        usage, new_tuple = CPUMonitor._compute_usage_from_jiffies(prev, curr_stats)
        self.assertEqual(usage, 0.0)
        self.assertEqual(new_tuple, (2000, 6000))

        # Now test 75% utilization:
        # prev = (2000, 6000)
        # next: delta total = 1000, delta idle = 250 -> usage = ((1000 - 250) / 1000) * 100 = 75.0%
        # idle_all = 2000 + 250 = 2250 (idle=2200, iowait=50)
        # non_idle = 4000 + 750 = 4750 (user=3550, system=1000, etc.)
        # total = 2250 + 4750 = 7000
        curr_stats_2 = [3550, 0, 1000, 2200, 50, 100, 100, 0]
        usage_2, new_tuple_2 = CPUMonitor._compute_usage_from_jiffies(new_tuple, curr_stats_2)
        self.assertEqual(usage_2, 75.0)
        self.assertEqual(new_tuple_2, (2250, 7000))

    def test_cpu_zero_delta(self):
        """Zero delta (no elapsed time) must yield 0.0% without division-by-zero crash."""
        prev = (1000, 5000)
        curr_stats = [2500, 0, 1500, 900, 100, 0, 0, 0]  # total = 1000 + 4000 = 5000
        usage, _ = CPUMonitor._compute_usage_from_jiffies(prev, curr_stats)
        self.assertEqual(usage, 0.0)

    def test_cpuinfo_parsing_with_mock_file(self):
        with tempfile.NamedTemporaryFile("w+", delete=False) as f:
            f.write(
                "processor\t: 0\n"
                "vendor_id\t: GenuineIntel\n"
                "model name\t: Intel(R) Core(TM) i7-10750H CPU @ 2.60GHz\n"
                "cpu MHz\t\t: 2592.000\n"
                "cache size\t: 12288 KB\n\n"
                "processor\t: 1\n"
                "vendor_id\t: GenuineIntel\n"
                "model name\t: Intel(R) Core(TM) i7-10750H CPU @ 2.60GHz\n"
            )
            temp_path = f.name

        try:
            monitor = CPUMonitor(stat_path="/nonexistent/stat", cpuinfo_path=temp_path)
            info = monitor.parse_cpuinfo()
            self.assertEqual(info["model_name"], "Intel(R) Core(TM) i7-10750H CPU @ 2.60GHz")
            self.assertEqual(info["vendor_id"], "GenuineIntel")
            self.assertEqual(info["core_count"], 2)
            self.assertEqual(info["cache_size"], "12288 KB")
        finally:
            os.remove(temp_path)


class TestMemoryCalculations(unittest.TestCase):
    """Verifies RAM and Swap calculation formulas according to kernel standards."""

    def test_memory_formula_modern_kernel(self):
        with tempfile.NamedTemporaryFile("w+", delete=False) as f:
            f.write(
                "MemTotal:       16000000 kB\n"
                "MemFree:         4000000 kB\n"
                "MemAvailable:   12000000 kB\n"
                "Buffers:          500000 kB\n"
                "Cached:          3500000 kB\n"
                "SwapTotal:       2000000 kB\n"
                "SwapFree:        1500000 kB\n"
            )
            temp_path = f.name

        try:
            info = get_memory_info(temp_path)
            self.assertTrue(info["supported"])
            # Used = MemTotal - MemAvailable = 16000000 - 12000000 = 4000000 kB
            self.assertEqual(info["used_ram"]["raw_kb"], 4000000)
            # Utilization % = 4000000 / 16000000 * 100 = 25.0%
            self.assertEqual(info["memory_utilization_percent"], 25.0)
            # Swap Used = 2000000 - 1500000 = 500000 kB -> 25.0%
            self.assertEqual(info["swap"]["used"]["raw_kb"], 500000)
            self.assertEqual(info["swap"]["utilization_percent"], 25.0)
        finally:
            os.remove(temp_path)

    def test_memory_formula_legacy_fallback(self):
        with tempfile.NamedTemporaryFile("w+", delete=False) as f:
            # MemAvailable omitted (simulating kernel < 3.14)
            f.write(
                "MemTotal:       10000000 kB\n"
                "MemFree:         2000000 kB\n"
                "Buffers:         1000000 kB\n"
                "Cached:          2000000 kB\n"
            )
            temp_path = f.name

        try:
            info = get_memory_info(temp_path)
            self.assertTrue(info["supported"])
            # Fallback Used = MemTotal - MemFree - Buffers - Cached = 10000000 - 5000000 = 5000000 kB
            self.assertEqual(info["used_ram"]["raw_kb"], 5000000)
            self.assertEqual(info["memory_utilization_percent"], 50.0)
        finally:
            os.remove(temp_path)

    def test_byte_formatting(self):
        fmt = format_bytes(1048576)  # Exactly 1 GB = 1024 * 1024 kB
        self.assertEqual(fmt["mb"], 1024.0)
        self.assertEqual(fmt["gb"], 1.0)
        self.assertEqual(fmt["formatted"], "1.0 GB")


class TestUptimeCalculations(unittest.TestCase):
    """Verifies uptime parser and conversion to days, hours, mins, secs."""

    def test_uptime_parsing(self):
        with tempfile.NamedTemporaryFile("w+", delete=False) as f:
            # 90061 seconds = 1 day (86400) + 1 hour (3600) + 1 min (60) + 1 sec
            f.write("90061.25 360245.80\n")
            temp_path = f.name

        try:
            info = get_uptime_info(temp_path)
            self.assertTrue(info["supported"])
            self.assertEqual(info["days"], 1)
            self.assertEqual(info["hours"], 1)
            self.assertEqual(info["minutes"], 1)
            self.assertEqual(info["seconds"], 1)
            self.assertIn("1 day, 1 hour, 1 min, 1 sec", info["formatted_uptime"])
        finally:
            os.remove(temp_path)


class TestLoadCalculations(unittest.TestCase):
    """Verifies parsing of /proc/loadavg."""

    def test_load_parsing(self):
        with tempfile.NamedTemporaryFile("w+", delete=False) as f:
            f.write("0.45 0.52 0.38 3/420 18920\n")
            temp_path = f.name

        try:
            info = get_load_info(temp_path)
            self.assertTrue(info["supported"])
            self.assertEqual(info["load_1m"], 0.45)
            self.assertEqual(info["load_5m"], 0.52)
            self.assertEqual(info["load_15m"], 0.38)
            self.assertEqual(info["runnable_entities"], 3)
            self.assertEqual(info["total_scheduling_entities"], 420)
            self.assertEqual(info["last_created_pid"], 18920)
        finally:
            os.remove(temp_path)


class TestProcessStatusParser(unittest.TestCase):
    """Verifies parsing of /proc/[PID]/status and transient process handling."""

    def test_parse_valid_status_file(self):
        temp_dir = tempfile.mkdtemp()
        try:
            status_file = os.path.join(temp_dir, "status")
            with open(status_file, "w") as f:
                f.write(
                    "Name:\tpython3\n"
                    "Umask:\t0022\n"
                    "State:\tS (sleeping)\n"
                    "Tgid:\t1234\n"
                    "PPid:\t567\n"
                    "Threads:\t4\n"
                    "VmSize:\t  24560 kB\n"
                    "VmRSS:\t   8192 kB\n"
                )
            proc_info = parse_process_status(temp_dir)
            self.assertIsNotNone(proc_info)
            self.assertEqual(proc_info["name"], "python3")
            self.assertEqual(proc_info["state_char"], "S")
            self.assertEqual(proc_info["ppid"], 567)
            self.assertEqual(proc_info["vm_rss_kb"], 8192)
            self.assertEqual(proc_info["vm_rss_mb"], 8.0)
            self.assertEqual(proc_info["threads"], 4)
        finally:
            import shutil
            shutil.rmtree(temp_dir, ignore_errors=True)

    def test_nonexistent_process_dir(self):
        proc_info = parse_process_status("/nonexistent/pid/999999")
        self.assertIsNone(proc_info)


@unittest.skipUnless(HAS_FLASK, "Flask is required for REST endpoint tests. Install via 'pip install flask'")
class TestFlaskEndpoints(unittest.TestCase):
    """Verifies that all API endpoints respond properly without crashing."""

    def setUp(self):
        if not HAS_FLASK or app is None:
            self.skipTest("Flask not installed")
        self.app = app.test_client()
        self.app.testing = True

    def test_dashboard_index(self):
        response = self.app.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Linux System Monitor", response.data)

    def test_api_system(self):
        response = self.app.get("/api/system")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("supported", data)

    def test_api_cpu(self):
        response = self.app.get("/api/cpu")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("supported", data)

    def test_api_memory(self):
        response = self.app.get("/api/memory")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("supported", data)

    def test_api_uptime(self):
        response = self.app.get("/api/uptime")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("supported", data)

    def test_api_load(self):
        response = self.app.get("/api/load")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("supported", data)

    def test_api_processes(self):
        response = self.app.get("/api/processes")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("supported", data)

    def test_api_summary(self):
        response = self.app.get("/api/summary")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("timestamp", data)
        self.assertIn("system", data)
        self.assertIn("cpu", data)
        self.assertIn("memory", data)
        self.assertIn("uptime", data)
        self.assertIn("load", data)
        self.assertIn("processes", data)

    def test_api_health(self):
        response = self.app.get("/api/health")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["status"], "healthy")
        self.assertIn("has_proc_filesystem", data)


if __name__ == "__main__":
    unittest.main()
