"""
Linux System Information Monitor - Flask Backend Application
Provides modular REST API endpoints reading real-time system metrics directly
from the Linux /proc filesystem and OS interfaces.
"""

import os
import sys
import time
from flask import Flask, jsonify, render_template, request, Response

from monitors.system_info import get_system_info
from monitors.cpu_monitor import get_cpu_info
from monitors.memory_monitor import get_memory_info
from monitors.uptime_monitor import get_uptime_info
from monitors.load_monitor import get_load_info
from monitors.process_monitor import get_processes_info

app = Flask(__name__, static_folder="static", template_folder="templates")


@app.after_request
def add_cache_headers(response: Response) -> Response:
    """Ensure dynamic monitoring endpoints are never cached by browsers or proxies."""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


@app.route("/")
def index():
    """Renders the main monitoring dashboard UI."""
    return render_template("index.html")


@app.route("/api/system", methods=["GET"])
def api_system():
    """Returns OS, distribution, kernel, hostname, and architecture details."""
    data = get_system_info()
    return jsonify(data)


@app.route("/api/cpu", methods=["GET"])
def api_cpu():
    """Returns CPU model, cores, and live utilization calculated from /proc/stat."""
    data = get_cpu_info()
    return jsonify(data)


@app.route("/api/memory", methods=["GET"])
def api_memory():
    """Returns physical RAM and Swap statistics calculated from /proc/meminfo."""
    data = get_memory_info()
    return jsonify(data)


@app.route("/api/uptime", methods=["GET"])
def api_uptime():
    """Returns system uptime and formatted days/hours/minutes/seconds from /proc/uptime."""
    data = get_uptime_info()
    return jsonify(data)


@app.route("/api/load", methods=["GET"])
def api_load():
    """Returns 1m, 5m, 15m load averages from /proc/loadavg."""
    data = get_load_info()
    return jsonify(data)


@app.route("/api/processes", methods=["GET"])
def api_processes():
    """
    Returns running processes inspected dynamically from /proc/[PID]/.
    Query parameters:
      - search: string to match against PID or process name
      - sort_by: 'pid', 'memory', 'name', 'ppid' (default: 'pid')
      - order: 'asc' or 'desc' (default: 'asc')
      - limit: integer max processes to return (default: all)
    """
    search = request.args.get("search", None)
    sort_by = request.args.get("sort_by", "pid")
    order = request.args.get("order", "asc")
    ascending = order.lower() != "desc"
    limit_str = request.args.get("limit", None)
    limit = int(limit_str) if limit_str and limit_str.isdigit() else None

    data = get_processes_info(
        search=search,
        sort_by=sort_by,
        ascending=ascending,
        limit=limit,
    )
    return jsonify(data)


@app.route("/api/summary", methods=["GET"])
def api_summary():
    """
    Consolidated endpoint that fetches all current system metrics in a single round-trip,
    minimizing network overhead during 2-second periodic polling.
    """
    system_data = get_system_info()
    cpu_data = get_cpu_info()
    mem_data = get_memory_info()
    uptime_data = get_uptime_info()
    load_data = get_load_info()
    processes_data = get_processes_info(limit=50)  # Top 50 by default for quick view

    return jsonify({
        "timestamp": time.time(),
        "system": system_data,
        "cpu": cpu_data,
        "memory": mem_data,
        "uptime": uptime_data,
        "load": load_data,
        "processes": processes_data,
    })


@app.route("/api/health", methods=["GET"])
def api_health():
    """Health check endpoint validating runtime environment compatibility."""
    has_proc = os.path.isdir("/proc")
    return jsonify({
        "status": "healthy",
        "has_proc_filesystem": has_proc,
        "platform": sys.platform,
        "compatible_environment": has_proc and sys.platform.startswith("linux"),
        "timestamp": time.time(),
    })


@app.errorhandler(404)
def handle_404(e):
    return jsonify({"error": "Endpoint not found", "status": 404}), 404


@app.errorhandler(500)
def handle_500(e):
    return jsonify({"error": "Internal server error", "status": 500, "details": str(e)}), 500


if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("DEBUG", "False").lower() in ("true", "1")
    
    print("=" * 65)
    print(" Linux System Information Monitor - Backend Service")
    print("=" * 65)
    print(f" Platform Detected : {sys.platform}")
    print(f" /proc Filesystem  : {'Available' if os.path.isdir('/proc') else 'NOT FOUND'}")
    if not os.path.isdir("/proc"):
        print(" [!] WARNING: /proc is not available in this operating system.")
        print("     To monitor real system statistics, run this on genuine Linux/WSL.")
    print(f" Listening on      : http://{host}:{port}")
    print("=" * 65)
    
    app.run(host=host, port=port, debug=debug)
